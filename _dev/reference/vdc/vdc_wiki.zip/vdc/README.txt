Valve Developer Community pages saved by VDC Saver on 2026-11-21.
Source: https://developer.valvesoftware.com/ (see the site for its license).

wikitext/  the source of each page (.wiki), from the wiki's API
text/      the page as it was shown (.txt), for pages you visited
index.tsv  one row per file: path, title, namespace, kind, revision, timestamp, categories

Files: 10224, text: 57.3 MB.
Left out (other games by the "Skip other games" lists, and translations when English only): 0 files.
Em dashes were changed to " - " (the project's house rule); 236 translations and SteamVR/helper pages were left out. Read it with python3 _dev/tools/vdc.py.
